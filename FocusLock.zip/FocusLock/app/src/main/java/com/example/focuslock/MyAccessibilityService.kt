package com.example.focuslock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.*

class MyAccessibilityService : AccessibilityService() {
    private lateinit var prefs: SharedPreferences

    override fun onServiceConnected() {
        prefs = getSharedPreferences("FocusLockPrefs", MODE_PRIVATE)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        val blockedApps = listOf(
            "com.facebook.katana", // فيسبوك
            "com.google.android.youtube", // يوتيوب
            "com.instagram.android", // إنستغرام
            "com.zhiliaoapp.musically" // تيك توك
        )

        val breakEndTime = prefs.getLong("breakEndTime", 0)
        val manualLockEndTime = prefs.getLong("manualLockEndTime", 0)

        if (System.currentTimeMillis() < breakEndTime) {
            return // السماح أثناء الاستراحة
        }

        if (System.currentTimeMillis() < manualLockEndTime || (packageName in blockedApps && isBlockedTime())) {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            startActivity(intent)
        }
    }

    private fun isBlockedTime(): Boolean {
        val currentTime = Calendar.getInstance().time
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentTimeString = sdf.format(currentTime)

        val morningStart = prefs.getString("morning_start", "") ?: return false
        val morningEnd = prefs.getString("morning_end", "") ?: return false
        val eveningStart = prefs.getString("evening_start", "") ?: return false
        val eveningEnd = prefs.getString("evening_end", "") ?: return false

        return currentTimeString >= morningStart && currentTimeString <= morningEnd ||
                currentTimeString >= eveningStart && currentTimeString <= eveningEnd
    }

    override fun onInterrupt() {}
}