import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.ComponentName
import android.content.Intent
import android.app.admin.DevicePolicyManager

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    createNotificationChannel()
    prefs = getSharedPreferences("FocusLockPrefs", MODE_PRIVATE)

    // تفعيل الحظر اليدوي لمدة ساعة
    val manualLockEndTime = prefs.getLong("manualLockEndTime", 0)
    if (manualLockEndTime == 0L) {
        val endTime = System.currentTimeMillis() + 60 * 60 * 1000 // ساعة واحدة
        prefs.edit().putLong("manualLockEndTime", endTime).apply()
        showNotification("تم تفعيل القفل لمدة ساعة!")
    }

    val morningStart = findViewById<EditText>(R.id.morningStart)
    val morningEnd = findViewById<EditText>(R.id.morningEnd)
    val eveningStart = findViewById<EditText>(R.id.eveningStart)
    val eveningEnd = findViewById<EditText>(R.id.eveningEnd)
    val password = findViewById<EditText>(R.id.password)
    val activateButton = findViewById<Button>(R.id.activateButton)
    val breakButton = findViewById<Button>(R.id.breakButton)

    activateButton.setOnClickListener {
        val morningStartTime = morningStart.text.toString()
        val morningEndTime = morningEnd.text.toString()
        val eveningStartTime = eveningStart.text.toString()
        val eveningEndTime = eveningEnd.text.toString()
        val passwordText = password.text.toString()

        if (morningStartTime.isNotEmpty() && morningEndTime.isNotEmpty() &&
            eveningStartTime.isNotEmpty() && eveningEndTime.isNotEmpty() &&
            passwordText.isNotEmpty()) {
            with(prefs.edit()) {
                putString("morning_start", morningStartTime)
                putString("morning_end", morningEndTime)
                putString("evening_start", eveningStartTime)
                putString("evening_end", eveningEndTime)
                putString("password", passwordText)
                apply()
            }
            requestDeviceAdmin()
            showNotification("تم حفظ الإعدادات! ركز الآن.")
        } else {
            showNotification("يرجى ملء جميع الحقول!")
        }
    }

    breakButton.setOnClickListener {
        showPasswordDialog()
    }
}

private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            "FocusLockChannel",
            "قفل التركيز",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun showNotification(message: String) {
    val notification = NotificationCompat.Builder(this, "FocusLockChannel")
        .setSmallIcon(R.drawable.ic_lock)
        .setContentTitle("قفل التركيز")
        .setContentText(message)
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)
        .build()

    with(NotificationManagerCompat.from(this)) {
        notify(1, notification)
    }
}

private fun requestDeviceAdmin() {
    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
    val componentName = ComponentName(this, MyDeviceAdminReceiver::class.java)
    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "هذا الإذن مطلوب لمنع إلغاء تثبيت التطبيق.")
    startActivity(intent)
}

private fun showPasswordDialog() {
    val dialog = android.app.AlertDialog.Builder(this)
    val input = android.widget.EditText(this)
    dialog.setTitle("أدخل كلمة المرور")
    dialog.setView(input)
    dialog.setPositiveButton("تأكيد") { _, _ ->
        val enteredPassword = input.text.toString()
        val savedPassword = prefs.getString("password", "")
        if (enteredPassword == savedPassword) {
            val breakEndTime = System.currentTimeMillis() + 5 * 60 * 1000 // 5 دقائق
            prefs.edit().putLong("breakEndTime", breakEndTime).apply()
            showNotification("تم تفعيل الاستراحة لمدة 5 دقائق!")
        } else {
            showNotification("كلمة المرور غير صحيحة!")
        }
    }
    dialog.setNegativeButton("إلغاء") { d, _ -> d.cancel() }
    dialog.show()
}